//visualizacion del mapa modo oscuro
const map = L.map('map', {
  zoomControl:false
}).setView([20, 0], 2);

L.tileLayer(
  'https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png',
  {
    subdomains:'abcd',
    maxZoom:19
  }
).addTo(map);


//detecto el pai del mensaje
function detectCountry(text){

  const lower = text.toLowerCase();

  for(const country of capitales){
    if(
      lower.includes(
        country.pais.toLowerCase()
      )
    ){
      return country;
    }
  }

  return null;
}


//cargo las questiones del polymarket, sin todos los demas datos
async function loadQuestions(){

  const res =
    await fetch(
      "https://gamma-api.polymarket.com/markets?active=true&limit=100"
    );

  const data =
    await res.json();

  return data.map(x => x.question);
}


//desde aqui todo funciona
async function main(){

  const markets = await loadQuestions(); //cargo las questiones

  const counts = {};

  for(const m of markets){ //recorro el array

    const loc = detectCountry(m); //detecto el pail

    if(!loc) continue;

    const key = loc.capital;

    if(!counts[key]){

      counts[key] = {
        ...loc,
        count:0
      };
    }

    counts[key].count++;
  }

  //visualizo los valores del objeto
  Object.values(counts).forEach(city => {

    //circulo interior de prueba
    L.circleMarker(
      [city.latitud, city.longitud],
      {
        radius: 20 + city.count * 6,
        color: "orange",
        fillColor:"orange",
        fillOpacity:0.15,
        opacity:0
      }
    ).addTo(map);

    //circulo de fuera
    const marker =
      L.circleMarker(
        [city.latitud, city.longitud],
        {
          radius: 8 + city.count * 2,
          color:"#ffb000",
          weight:2,
          fillColor:"#ff9900",
          fillOpacity:0.9
        }
      ).addTo(map);

    // LABEL COUNTRY CODE

    const labelIcon = L.divIcon({
    className: 'country-label',
    html: `
        <div class="label-text">
            ${city.codigo || city.pais.slice(0,2).toUpperCase()}
            </div>
        `,
        iconSize: [40, 20],
        iconAnchor: [20, -10]
        });

    L.marker(
        [city.latitud - 2.2, city.longitud],
        {
            icon: labelIcon
        }
        ).addTo(map);


    marker.bindPopup(`
      <div style="min-width:160px">
        <b style="font-size:16px">
          ${city.capital}
        </b>
        <br><br>

        ${city.pais}
        <br>

        Mentions:
        <b>${city.count}</b>
      </div>
    `);

  });


  document.getElementById("panel").innerHTML =
  `
    <div style="font-size:18px;font-weight:bold">
      Polymarket Global Activity
    </div>

    <div style="margin-top:8px">
      Countries detected:
      <b>${Object.keys(counts).length}</b>
    </div>
  `;
}

main();
